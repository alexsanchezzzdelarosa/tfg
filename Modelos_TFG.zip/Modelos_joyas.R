#### Sector Joyas

datos_joyas <- read_excel("Datos Industrias TFG (2).xlsx", sheet = "Joyas")   #almacenamos en la variable datos_1 el archivo con los datos

head(datos_joyas)           #visualizamos el contenido principal del archivo
summary(datos_joyas)
str(datos_joyas)

modelo_joyas_1 <- lm(datos_joyas$Inversion_Neta ~ datos_joyas$Impresiones+datos_coches$CPM+datos_joyas$Clicks+datos_joyas$CPC+datos_joyas$CTR+datos_joyas$Shares+datos_joyas$comments+datos_joyas$link_clicks+datos_joyas$likes+datos_joyas$post_saves+datos_joyas$Engagement+datos_joyas$CPE+datos_joyas$Engagement_Rate, datos_joyas)   #almacenamos en la variable modelo_1 la regresión lineal que hemos definido
summary(modelo_joyas_1)           #mostramos los resultados de la regresión
modelo_joyas_1$coefficients         #vemos los coeficientes de las diferentes variables independientes

modelo_joyas_2  <- lm(datos_coches$Inversion_Neta ~ datos_coches$Impresiones+datos_coches$CPM+datos_coches$Clicks+datos_coches$Shares+datos_coches$comments+datos_coches$link_clicks+datos_coches$likes+datos_coches$post_saves+datos_coches$Rep_3sec+datos_coches$Engagement+datos_coches$CPE+datos_coches$Engagement_Rate, datos_coches)
summary(modelo_joyas_2)
modelo_joyas_2$coefficients



# Crear un data frame con las variables de interés
df_joyas2 <- data.frame(datos_joyas$Inversion_Neta,datos_joyas$Impresiones, datos_joyas$Clicks, datos_joyas$Shares, datos_joyas$comments, datos_joyas$link_clicks, datos_joyas$likes, datos_joyas$post_saves) # Reemplaza var1, var2 y var3 con tus variables

# Calcular la matriz de correlación
matriz_cor_joyas2 <- cor(df_joyas2)

# Mostrar la matriz de correlación
print(matriz_cor_joyas2)

# Instalar y cargar la biblioteca corrplot
install.packages("corrplot")
library(corrplot)


# Mostrar la matriz de correlación utilizando corrplot
corrplot(matriz_cor_joyas2, method = "number", type = "full")

modelo_joyas3 <- lm(Inversion_Neta ~ Impresiones + Clicks + post_saves + link_clicks, datos_coches)
# Reemplaza "Inversion_neta" con el nombre real de tu variable dependiente y "Impresiones", "Clicks" y "Shares" con los nombres reales de tus variables independientes
nuevos_datos_joyas3 <- data.frame(Impresiones = 3310000, Clicks = 3000, post_saves = 31, link_clicks = 5)

predicciones_joyas <- predict(modelo_joyas3, nuevos_datos_joyas3)
print(predicciones_joyas)

##### Facebook

# Definir los valores de las variables independientes para la predicción
Impresiones <- 100000
Clicks <- 1000
post_saves <- 31

# Definir los pesos de las variables independientes
peso_impresiones <- 0.28
peso_clicks <- 0.24
peso_link <- 0.27
peso_post_saves <- 0.19

# Calcular los valores ponderados de las variables independientes
valor_ponderado_impresiones <- datos_joyas.Impresiones * peso_impresiones
valor_ponderado_clicks <- datos_joyas.Clicks * peso_clicks
valor_ponderado_shares <- datos_joyas.Shares * peso_shares
valor_ponderado_post_saves <- datos_joyas.post_saves * peso_post_saves

##Predicciones
datos_joyas_FB <- read_excel("Datos Industrias TFG (2).xlsx", sheet = "FB joyas")


modelo_joyas_pred_FB <- lm(Inversion_Neta ~ Impresiones + link_clicks + Clicks + post_saves , datos_joyas_FB)
# Reemplaza "Inversion_neta" con el nombre real de tu variable dependiente y "Impresiones", "Clicks" y "Shares" con los nombres reales de tus variables independientes
nuevos_datos_joyas_FB <- data.frame(Impresiones = 10000000, Clicks = 100000 ,link_clicks = 50000, post_saves = 50 )

predicciones_joyas_FB <- predict(modelo_joyas_pred_FB, nuevos_datos_joyas_FB)
print(predicciones_joyas_FB)

#### Instagram

##Predicciones
datos_joyas_IG <- read_excel("Datos Industrias TFG (2).xlsx", sheet = "IG joyas")


modelo_joyas_pred_IG <- lm(Inversion_Neta ~ Impresiones + post_saves , datos_joyas_IG)
# Reemplaza "Inversion_neta" con el nombre real de tu variable dependiente y "Impresiones", "Clicks" y "Shares" con los nombres reales de tus variables independientes
nuevos_datos_joyas_IG <- data.frame(Impresiones = 10000000,  post_saves = 50, link_clicks = 50000)

predicciones_joyas_IG <- predict(modelo_joyas_pred_IG, nuevos_datos_joyas_IG)
print(predicciones_joyas_IG)


