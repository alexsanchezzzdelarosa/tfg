#### Sector Restaurantes


datos_restaurantes <- read_excel("Datos Industrias TFG (2).xlsx", sheet = "restaurantes")   #almacenamos en la variable datos_1 el archivo con los datos

head(datos_restaurantes)           #visualizamos el contenido principal del archivo
summary(datos_restaurantes)
str(datos_restaurantes)

modelo_restaurantes_1 <- lm(datos_restaurantes$Inversion_Neta ~ datos_restaurantes$Impresiones+datos_restaurantes$CPM+datos_restaurantes$Clicks+datos_restaurantes$CPC+datos_restaurantes$CTR+datos_restaurantes$Shares+datos_restaurantes$comments+datos_restaurantes$link_clicks+datos_restaurantes$likes+datos_restaurantes$post_saves, datos_restaurantes)   #almacenamos en la variable modelo_1 la regresión lineal que hemos definido
summary(modelo_restaurantes_1)           #mostramos los resultados de la regresión
modelo_restaurantes_1$coefficients         #vemos los coeficientes de las diferentes variables independientes

modelo_restaurantes_2  <- lm(datos_restaurantes$Inversion_Neta ~ datos_restaurantes$Impresiones+datos_restaurantes$CPM+datos_restaurantes$Clicks +datos_restaurantes$link_clicks+datos_restaurantes$post_saves, datos_restaurantes)
summary(modelo_restaurantes_2)
modelo_restaurantes_2$coefficients

# Calcular la correlación de Pearson entre dos variables
correlation_restaurantes1 <- cor(datos_restaurantes$Impresiones, datos_restaurantes$Inversion_Neta)
print(correlation_restaurantes1)


# Crear un data frame con las variables de interés
df_restaurantes <- data.frame(datos_restaurantes$Inversion_Neta , datos_restaurantes$Impresiones,  datos_restaurantes$Clicks , datos_restaurantes$link_clicks, datos_restaurantes$post_saves) # Reemplaza var1, var2 y var3 con tus variables

# Calcular la matriz de correlación
matriz_cor_restaurantes <- cor(df_restaurantes)

# Mostrar la matriz de correlación
print(matriz_cor_restaurantes)

# Instalar y cargar la biblioteca corrplot
install.packages("corrplot")
library(corrplot)


# Mostrar la matriz de correlación utilizando corrplot
corrplot(matriz_cor_restaurantes, method = "number", type = "full")

modelo_restaurantes4 <- lm(Inversion_Neta ~ Impresiones + Clicks +  link_clicks, datos_restaurantes)
# Reemplaza "Inversion_neta" con el nombre real de tu variable dependiente y "Impresiones", "Clicks" y "Shares" con los nombres reales de tus variables independientes
nuevos_datos_restaurantes3 <- data.frame(Impresiones = 3310000, Clicks = 3000, link_clicks = 5)

predicciones_restaurantes1 <- predict(modelo_restaurantes4, nuevos_datos_restaurantes3)
print(predicciones_restaurantes1)

##### Facebook

# Definir los valores de las variables independientes para la predicción
Impresiones <- 310000
Clicks <- 3000
post_saves <- 31

# Definir los pesos de las variables independientes
peso_impresiones <- 0.375
peso_clicks <- 0.33
peso_link <- 0.292

# Calcular los valores ponderados de las variables independientes
valor_ponderado_impresiones <- datos_coches.Impresiones * peso_impresiones
valor_ponderado_clicks <- datos_coches.Clicks * peso_clicks
valor_ponderado_link <- datos_coches.link * peso_link


##Predicciones
datos_restaurantes_FB <- read_excel("Datos Industrias TFG (2).xlsx", sheet = "FB restau")


modelo_restaurantes_pred_FB <- lm(Inversion_Neta ~ Impresiones + Clicks + link_clicks, datos_restaurantes_FB)
# Reemplaza "Inversion_neta" con el nombre real de tu variable dependiente y "Impresiones", "Clicks" y "Shares" con los nombres reales de tus variables independientes
nuevos_datos_restaurantes_FB <- data.frame(Impresiones = 10000000, Clicks = 40000, link_clicks = 25000)

predicciones_restaurantes_FB <- predict(modelo_restaurantes_pred_FB, nuevos_datos_restaurantes_FB)
print(predicciones_restaurantes_FB)



### TikTok y Twitter

##Predicciones
datos_restarantes_TK1 <- read_excel("Datos Industrias TFG (2).xlsx", sheet = "TK restau")


modelo_pred_restaurantes_TK <- lm(Inversion_Neta ~ Impresiones  , datos_restarantes_TK1)
# Reemplaza "Inversion_neta" con el nombre real de tu variable dependiente y "Impresiones", "Clicks" y "Shares" con los nombres reales de tus variables independientes
nuevos_datos_restaurantes_TK <- data.frame(Impresiones = 10000000)

predicciones_restaurantes_TK <- predict(modelo_pred_restaurantes_TK, nuevos_datos_restaurantes_TK)
print(predicciones_restaurantes_TK)




