install.packages("readxl") #instalar paquete readxl para poder leer archivos .xlsx

library (readxl)           #cargamos la librería
library (stats)


datos_comida <- read_excel("Datos Industrias TFG (2).xlsx", sheet = "comida")   #almacenamos en la variable datos_1 el archivo con los datos

head(datos_comida)           #visualizamos el contenido principal del archivo
summary(datos_comida)
str(datos_comida)


modelo_comida_1 <- lm(datos_comida$Inversion_Neta ~ datos_comida$Impresiones+datos_comida$CPM+datos_comida$Clicks+datos_comida$CPC+datos_comida$CTR+datos_comida$Shares+datos_comida$comments+datos_comida$link_clicks+datos_comida$likes+datos_comida$post_saves+datos_comida$Rep_3sec+datos_comida$Engagement+datos_comida$CPE+datos_comida$Engagement_Rate, datos_comida)   #almacenamos en la variable modelo_1 la regresión lineal que hemos definido
summary(modelo_comida_1)           #mostramos los resultados de la regresión
modelo_comida_1$coefficients         #vemos los coeficientes de las diferentes variables independientes

plot(datos_comida$Inversion_Neta~datos_comida$Impresiones+datos_comida$CPM+datos_comida$Clicks+datos_comida$CPC+datos_comida$CTR+datos_comida$Shares+datos_comida$comments+datos_comida$link_clicks+datos_comida$likes+datos_comida$post_saves+datos_comida$Rep_3sec+datos_comida$Engagement+datos_comida$CPE+datos_comida$Engagement_Rate, datos_comida)      #graficamos 
abline(modelo_comida_1)

modelo_comida_2 <- lm(datos_comida$Inversion_Neta ~ datos_comida$Impresiones+datos_comida$CPM+datos_comida$Clicks+datos_comida$CTR+datos_comida$Shares+datos_comida$post_saves+datos_comida$Rep_3sec, datos_comida)   #almacenamos en la variable modelo_1 la regresión lineal que hemos definido
summary(modelo_comida_2)           #mostramos los resultados de la regresión
modelo_comida_2$coefficients         #vemos los coeficientes de las diferentes variables independientes

plot(datos_comida$Inversion_Neta~datos_comida$Impresiones)      #graficamos 
abline(modelo_comida_2)


# Crear un data frame con las variables de interés
df_comida1 <- data.frame(datos_comida$Inversion_Neta, datos_comida$Impresiones, datos_comida$CPM, datos_comida$Clicks) # Reemplaza var1, var2 y var3 con tus variables

# Calcular la matriz de correlación
matriz_cor_comida1 <- cor(df_comida1)

# Mostrar la matriz de correlación
print(matriz_cor_comida1)

# Instalar y cargar la biblioteca corrplot
install.packages("corrplot")
library(corrplot)


# Mostrar la matriz de correlación utilizando corrplot
corrplot(matriz_cor_comida1, method = "number", type = "full")

########## Comida Facebook
datos_comida_FB <- read_excel("Datos Industrias TFG (2).xlsx", sheet = "FB Comida") 

modelo_comida_1_FB <- lm(Inversion_Neta ~ Impresiones + Clicks, datos_comida_FB)   #almacenamos en la variable modelo_1 la regresión lineal que hemos definido
summary(modelo_comida_1_FB)           #mostramos los resultados de la regresión
modelo_comida_1_FB$coefficients 



# Definir los valores de las variables independientes para la predicción
impresiones <- 310000
clicks <- 3000
shares <- 31

# Definir los pesos de las variables independientes
peso_impresiones_FBComida <- 0.4348
peso_clicks_FBComida <- 0.5155
peso_CPM_FBComida <- 0.0497

# Calcular los valores ponderados de las variables independientes
valor_ponderado_impresiones_FBComida <- impresiones * peso_impresiones_FBComida
valor_ponderado_clicks_FBComida <- clicks * peso_clicks_FBComida
valor_ponderado_CPM_FBComida <- shares * peso_CPM_FBComida

# Crear un data frame con los valores ponderados de las variables independientes
nueva_observacion_FBComida <- data.frame(Impresiones = valor_ponderado_impresiones_FBComida, Clicks = valor_ponderado_clicks_FBComida, CPM = valor_ponderado_CPM_FBComida)

# Obtener la predicción de la variable dependiente con la ponderación
prediccion_FBComida <- predict(modelo_comida_1_FB, nueva_observacion_FBComida)

# Imprimir la predicción
print(prediccion_FBComida)


nuevos_datos_FBComida2 <- data.frame(Impresiones = 20000000, Clicks = 100000)

predicciones_FBComida2 <- predict(modelo_comida_1_FB, nuevos_datos_FBComida2)
print(predicciones_FBComida2)


# Calcular la media de las predicciones
media_predicciones_FBComida <- mean(predicciones_FBComida)

# Imprimir la media de las predicciones
print(media_predicciones_FBComida)

mediana_predicciones_FBComida <- median(predicciones_FBComida)
print(mediana_predicciones_FBComida)


#########  Comida Instagram

file.choose()
install.packages("readxl") #instalar paquete readxl para poder leer archivos .xlsx

library (readxl)           #cargamos la librería
library (stats)
datos_comida_IG <- read_excel("Datos Industrias TFG (2).xlsx", sheet = "IG Comida") 

modelo_comida_1_IG <- lm(Inversion_Neta ~ Impresiones + Clicks, datos_comida_IG)   #almacenamos en la variable modelo_1 la regresión lineal que hemos definido
summary(modelo_comida_1_IG)           #mostramos los resultados de la regresión
modelo_comida_1_IG$coefficients 



# Definir los valores de las variables independientes para la predicción
ImpresionesIGComida2 <- 6010000
clicksIGComida2 <- 7000
sharesIGComida2 <- 31

# Definir los pesos de las variables independientes
peso_Impresiones_IGComida2 <- 0.4348
peso_clicks_IGComida2 <- 0.5155
peso_CPM_IGComida2 <- 0.0497

# Calcular los valores ponderados de las variables independientes
valor_ponderado_Impresiones_IGComida2 <- impresionesIGComida2 * peso_impresiones_IGComida2
valor_ponderado_clicks_IGComida2 <- clicksIGComida2 * peso_clicks_IGComida2
valor_ponderado_CPM_IGComida2 <- sharesIGComida2 * peso_CPM_IGComida2

# Crear un data frame con los valores ponderados de las variables independientes
nueva_observacion_IGComida2 <- data.frame(valor_ponderado_Impresiones_IGComida2, valor_ponderado_clicks_IGComida2, valor_ponderado_CPM_IGComida2)

# Obtener la predicción de la variable dependiente con la ponderación
prediccion_IGComida2 <- predict(modelo_comida_1_IG, nueva_observacion_IGComida2)

# Imprimir la predicción
print(prediccion_IGComida2)


nuevos_datos_IGComida2 <- data.frame(Impresiones = 20000000, Clicks = 100000)

predicciones_IGComida2 <- predict(modelo_comida_1_IG, nuevos_datos_IGComida2)
print(predicciones_IGComida2)

primera_prediccionIGComida1 <- predicciones[1]
print(primera_prediccionIGComida1)

# Calcular la media de las predicciones
media_predicciones_IGComida <- mean(predicciones_IGComida)

# Imprimir la media de las predicciones
print(media_predicciones_IGComida)

#Mediana
mediana_predicciones_IGComida3 <- median(predicciones_IGComida2)
print(mediana_predicciones_IGComida3)


arbol_comida_1_IG <- rpart(datos_comida_IG$Inversion_Neta ~ datos_comida_IG$Impresiones+datos_comida_IG$CPM+datos_comida_IG$Clicks)

plot(arbol_comida_1_IG)
text(arbol_comida_1_IG)

library(rpart)


library(ggplot2)

# Datos de las predicciones de inversión en Facebook e Instagram
redes_sociales <- c("Facebook", "Instagram")
predicciones_facebook <- c(272.52, 284.23, 401.34, 556.40, 1178.96, 3645.05, 15854.75)
predicciones_instagram <- c(561.52, 583.78, 806.37, 1024.79, 2066.43, 6317.86, 27999.54)

# Crear el objeto de datos
datosgraficoIGFBComida <- data.frame(Redes_Sociales = rep(redes_sociales, each = 7),
                    Predicciones = c(predicciones_facebook, predicciones_instagram))

# Crear la gráfica de barras
library(ggplot2)
ggplot(datos, aes(x = Redes_Sociales, y = Predicciones, fill = Redes_Sociales)) +
  geom_bar(stat = "identity", width = 0.5) +
  labs(title = "Predicciones de Inversión en Facebook e Instagram",
       x = "Redes Sociales", y = "Predicción de Inversión") +
  theme_minimal() +
  theme(legend.position = "none")



