
#### Sector Coches


datos_coches <- read_excel("Datos Industrias TFG (2).xlsx", sheet = "coches")   #almacenamos en la variable datos_1 el archivo con los datos

head(datos_coches)           #visualizamos el contenido principal del archivo
summary(datos_coches)
str(datos_coches)

modelo_coches_1 <- lm(datos_coches$Inversion_Neta ~ datos_coches$Impresiones+datos_coches$CPM+datos_coches$Clicks+datos_coches$CPC+datos_coches$CTR+datos_coches$Shares+datos_coches$comments+datos_coches$link_clicks+datos_coches$likes+datos_coches$post_saves+datos_coches$Rep_3sec+datos_coches$Engagement+datos_coches$CPE+datos_coches$Engagement_Rate, datos_coches)   #almacenamos en la variable modelo_1 la regresión lineal que hemos definido
summary(modelo_coches_1)           #mostramos los resultados de la regresión
modelo_coches_1$coefficients         #vemos los coeficientes de las diferentes variables independientes

modelo_coches_2  <- lm(datos_coches$Inversion_Neta ~ datos_coches$Impresiones+datos_coches$CPM+datos_coches$Clicks+datos_coches$Shares+datos_coches$comments+datos_coches$link_clicks+datos_coches$likes+datos_coches$post_saves+datos_coches$Rep_3sec+datos_coches$Engagement+datos_coches$CPE+datos_coches$Engagement_Rate, datos_coches)
summary(modelo_coches_2)
modelo_coches_2$coefficients

# Calcular la correlación de Pearson entre dos variables
correlation_coches1 <- cor(datos_coches$Impresiones, datos_coches$Inversion_Neta)
print(correlation_coches1)


# Crear un data frame con las variables de interés
df_coches2 <- data.frame(datos_coches$Inversion_Neta,datos_coches$Impresiones, datos_coches$Clicks, datos_coches$Shares, datos_coches$comments, datos_coches$link_clicks, datos_coches$likes, datos_coches$post_saves) # Reemplaza var1, var2 y var3 con tus variables

# Calcular la matriz de correlación
matriz_cor_coches2 <- cor(df_coches2)

# Mostrar la matriz de correlación
print(matriz_cor_coches2)

# Instalar y cargar la biblioteca corrplot
install.packages("corrplot")
library(corrplot)


# Mostrar la matriz de correlación utilizando corrplot
corrplot(matriz_cor_coches2, method = "number", type = "full")

modelo_coches3 <- lm(Inversion_Neta ~ Impresiones + Clicks + post_saves + link_clicks, datos_coches)
# Reemplaza "Inversion_neta" con el nombre real de tu variable dependiente y "Impresiones", "Clicks" y "Shares" con los nombres reales de tus variables independientes
nuevos_datos_coches3 <- data.frame(Impresiones = 3310000, Clicks = 3000, post_saves = 31, link_clicks = 5)

predicciones3 <- predict(modelo_coches3, nuevos_datos_coches3)
print(predicciones3)

##### Facebook

# Definir los valores de las variables independientes para la predicción
Impresiones <- 310000
Clicks <- 3000
post_saves <- 31

# Definir los pesos de las variables independientes
peso_impresiones <- 0.3
peso_clicks <- 0.2
peso_shares <- 0.4
peso_post_saves <- 0.1

# Calcular los valores ponderados de las variables independientes
valor_ponderado_impresiones <- datos_coches.Impresiones * peso_impresiones
valor_ponderado_clicks <- datos_coches.Clicks * peso_clicks
valor_ponderado_shares <- datos_coches.Shares * peso_shares
valor_ponderado_post_saves <- datos_coches.post_saves * peso_post_saves

##Predicciones
datos_coches_FB <- read_excel("Datos Industrias TFG (2).xlsx", sheet = "FB Coches")


modelo_coches_pred_FB <- lm(Inversion_Neta ~ Impresiones + Clicks + link_clicks, datos_coches_FB)
# Reemplaza "Inversion_neta" con el nombre real de tu variable dependiente y "Impresiones", "Clicks" y "Shares" con los nombres reales de tus variables independientes
nuevos_datos_coches_FB <- data.frame(Impresiones = 7000000, Clicks = 7000, link_clicks = 4000)

predicciones_coches_FB <- predict(modelo_coches_pred_FB, nuevos_datos_coches_FB)
print(predicciones_coches_FB)

#### Instagram

##Predicciones
datos_coches_IG <- read_excel("Datos Industrias TFG (2).xlsx", sheet = "IG Coches")


modelo_coches_pred_IG <- lm(Inversion_Neta ~ Impresiones + Clicks + post_saves , datos_coches_IG)
# Reemplaza "Inversion_neta" con el nombre real de tu variable dependiente y "Impresiones", "Clicks" y "Shares" con los nombres reales de tus variables independientes
nuevos_datos_coches_IG <- data.frame(Impresiones = 7000000, Clicks = 7000, post_saves = 150)

predicciones_coches_IG <- predict(modelo_coches_pred_IG, nuevos_datos_coches_IG)
print(predicciones_coches_IG)


### TikTok y Twitter

##Predicciones
datos_coches_TKTW <- read_excel("Datos Industrias TFG (2).xlsx", sheet = "TKTW Coches")


modelo_coches_pred_TKTW <- lm(Inversion_Neta ~ Impresiones + Clicks, datos_coches_TKTW)
# Reemplaza "Inversion_neta" con el nombre real de tu variable dependiente y "Impresiones", "Clicks" y "Shares" con los nombres reales de tus variables independientes
nuevos_datos_coches_TKTW <- data.frame(Impresiones = 7000000, Clicks = 7000)

predicciones_coches_TKTW <- predict(modelo_coches_pred_TKTW, nuevos_datos_coches_TKTW)
print(predicciones_coches_TKTW)

















